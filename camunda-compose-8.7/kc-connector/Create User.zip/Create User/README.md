# Documentation

> This is a simple PoC which prooves that users can be remotely created on a Keycloak Server from Camunda

By using a simple _REST Outbound Connector_-Task in combination with a _User Task_ it is possible to:
- gather the information about a user for creation,
- send a `POST`-request to a remotely running middleware,
- create a user according to the provided information.
- view the middlewares repsonse in Camunda.
